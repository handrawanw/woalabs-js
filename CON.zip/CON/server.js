var http=require("http");
var fs=require("fs");
var server=http.createServer(function(req,res){
if(req.url==="/"){
	readF(req,res,"index.html",{"Content-Type":"text/html"});
	}else if(req.url.indexOf(".js")!=-1){
	readE(req,res,__dirname+req.url,{"Content-Type":"text/javascript"});
	}else{
		respon(res,404,{"Content-Type":"text/html"},"<h1>404 NOT FOUND</h1>");
	}
});

function readF(req,res,fil,tipe){
var o=fs.createReadStream(fil);
var htm="";
o.on("data",(c)=>{
	htm+=c;
	});
o.on("end",()=>{
	res.writeHead(200,tipe);
	res.end(htm);
	});
}

function readE(req,res,fil,tipe){
var o=fs.createReadStream(fil);
var htm="";
o.on("data",(c)=>{
	htm+=c;
	});
o.on("end",()=>{
	res.writeHead(200,tipe);
	res.end(Buffer.from(htm,"base64").toString("ascii"));
	});
}
function respon(res,code,tipe,htm){
	res.writeHead(code,tipe);
	res.end(htm);
}
server.listen(1111);
console.log("localhost:1111");

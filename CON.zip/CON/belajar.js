var fs=require("fs");
var ytdl=require("ytdl-core");
var url="https://www.youtube.com/watch?v=A02s8omM_hI";
ytdl(url).pipe(fs.createWriteStream("video.mp3"));
